package kaptainwutax.seedcracker.profile;

import kaptainwutax.seedcracker.finder.Finder;

public class YoloProfile extends CustomProfile {

	public YoloProfile() {
		super("WearBlackAllDay", false);
		this.setTypeState(Finder.Type.DUNGEON, true);
	}

}
