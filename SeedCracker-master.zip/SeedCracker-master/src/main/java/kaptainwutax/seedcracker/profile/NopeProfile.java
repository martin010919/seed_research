package kaptainwutax.seedcracker.profile;

public class NopeProfile extends FinderProfile {

	public NopeProfile() {
		super(false);
		this.author = "KaptainWutax";
		this.locked = true;
	}

}
